package Average.Student.MyInterFace;

public class App2 implements Plugin {
    @Override
    public void loadPlugin(String name) {
        System.out.println(name);
    }

    @Override
    public boolean excuatePlugin() {
        return false;
    }

    @Override
    public void closePlugin() {
        System.out.println("closed Application 2");
    }
}
