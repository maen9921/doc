package Average.Student.MyInterFace;

public class First {

    public void runPlugin (Plugin p){
        p.loadPlugin("Start");
        p.excuatePlugin();

    }
    public void closePlugin (Plugin p){
        p.closePlugin();
    }
    public void printDemo (Demo d){
        d.printData();
        d.getResult('a');
        d.loadPlugin("new");

    }
}
