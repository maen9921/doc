package Average.Student.MyInterFace;

public interface InterFace1 {

    final int x=10;

    public void printData();
    public int getResult(char c);
}
