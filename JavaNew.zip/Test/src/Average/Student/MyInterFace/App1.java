package Average.Student.MyInterFace;

public class App1 implements Plugin {
    @Override
    public void loadPlugin(String name) {
        System.out.println(name);
    }

    @Override
    public boolean excuatePlugin() {
        return true;
    }

    @Override
    public void closePlugin() {
        System.out.println("Closed Application 1");
    }
}
