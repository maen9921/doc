package Average.Student.MyInterFace;

public interface Plugin {

     void loadPlugin (String name);
     boolean excuatePlugin ();
     void closePlugin ();

}
