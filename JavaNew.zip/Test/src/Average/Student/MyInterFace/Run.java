package Average.Student.MyInterFace;

public class Run {

    public static void main(String[] args) {

       new Plugin() {
           @Override
           public void loadPlugin(String name) {
               System.out.println(name+" welcome");
           }

           @Override
           public boolean excuatePlugin() {
               return false;
           }

           @Override
           public void closePlugin() {

           }
       }.loadPlugin("maen");
//        App1 app1=new App1();
//        App2 app2=new App2();
//        Demo d=new Demo();

//        f.runPlugin(app1);
//        f.closePlugin(app1);
//        f.printDemo(d);

//       runPlugin(new Plugin() {
//            @Override
//            public void loadPlugin(String name) {
//                System.out.println("welcome to plugin");
//            }
//
//            @Override
//            public boolean excuatePlugin() {
//                return false;
//            }
//
//            @Override
//            public void closePlugin() {
//
//            }
//        });
    }
}
