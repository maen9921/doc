package Average.Student.MyInterFace;

public class App implements InterFace1 {
    @Override
    public void printData() {

    }

    @Override
    public int getResult(char c) {
        return 0;
    }
}
