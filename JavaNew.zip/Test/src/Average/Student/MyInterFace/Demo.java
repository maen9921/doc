package Average.Student.MyInterFace;

public class Demo extends First implements InterFace1 ,Plugin  {
    @Override
    public void printData()  {

    }

    @Override
    public int getResult(char c) {
        return 0;
    }

    @Override
    public void loadPlugin(String name) {

    }

    @Override
    public boolean excuatePlugin() {
        return false;
    }

    @Override
    public void closePlugin() {

    }
}
