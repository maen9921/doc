package Average.Student.Access_modifiers.public1;


import Average.Student.Access_modifiers.public2.Pup;

public class Main extends Pup {

	public static void main(String[] args) {
		
		Pup p = new Pup();
		p.see();

	}

}
