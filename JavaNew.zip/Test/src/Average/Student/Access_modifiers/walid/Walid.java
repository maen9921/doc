package Average.Student.Access_modifiers.walid;

 class Walid {

	
	public void see(){
		System.out.println("Muhammed Essa");	
		}
	}
	

