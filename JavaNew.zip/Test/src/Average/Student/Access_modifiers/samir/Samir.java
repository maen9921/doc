package Average.Student.Access_modifiers.samir;

public class Samir {

	protected void see(){
		System.out.println("Muhammed Essa");
		
	}
}
