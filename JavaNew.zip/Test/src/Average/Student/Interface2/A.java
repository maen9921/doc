package Average.Student.Interface2;

public class A implements EinterFace {


}
