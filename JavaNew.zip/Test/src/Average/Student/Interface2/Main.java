package Average.Student.Interface2;

public class Main {
    public static void main(String[] args) {

        C c=new C();
        A a=new A();
        c.Ido(a);
        System.out.println(c.getData());

    }
}
