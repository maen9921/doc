package Average.Student.Interface2;

public interface EinterFace {
}
