package Average.Student.Interface2;

public interface Hassan {

	public void see();
}
