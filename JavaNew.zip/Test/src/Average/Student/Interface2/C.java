package Average.Student.Interface2;

public class C {

    public void Ido (EinterFace x){
        System.out.println(x);
    }
    public EinterFace getData (){
        A a=new A();
        return a;
    }
}
