package Average.Student.Interface2;

public class B implements EinterFace {
}
