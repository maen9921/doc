package Average.Student.passingBycopyRefrenc;

public class PassingInObject {

	public static void main(String[] args) {
		
int nums[] = {1,2,3};
System.out.println("the number is : "+nums[0]);
addingValue(nums);
System.out.println("the number is : "+nums[0]);
	}

	private static void addingValue(int[] num){
	 num[0]++;
	 System.out.println("the number is : "+num[0]);
}
}
