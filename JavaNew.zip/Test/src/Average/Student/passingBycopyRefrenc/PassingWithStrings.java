package Average.Student.passingBycopyRefrenc;

public class PassingWithStrings {


	   public static void main(String args[])
	   {
		   PassingWithStrings ot =new PassingWithStrings();
	      ot.getSum(5,10);     // to call the non-static method
	   }

	   public void getSum(int x ,int y) // non-static method.
	   {
	      int a=x;
	      int b=y;
	      int c=a+b;
	      System.out.println("Sum is " + c);

	   }
	}
