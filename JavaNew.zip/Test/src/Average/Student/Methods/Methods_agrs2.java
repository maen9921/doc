package Average.Student.Methods;

class Hameed{
	public void Muham(String t){
		System.out.println(t);
	}
}

public class Methods_agrs2 {

	public static void main(String[] args) {
		
		Hameed essa = new Hameed();
		essa.Muham("Muhammed Essa");

	}

}
