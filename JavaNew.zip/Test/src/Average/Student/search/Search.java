package Average.Student.search;

import java.util.ArrayList;

public class Search {

	public static void main(String[] args) {

ArrayList<String> a = new ArrayList<String>();

  a.add("muhammed");
  a.add("essa");
  a.add("hameed");
  a.add("yousuf");
  a.add("omer");
 
 String name = "ali";

for (int i = 0; i < a.size();) {
	if(a.contains(name)){
	System.out.println(name);
	break;
	}else{
		System.out.println("This name : ("+name+") not in DB");
		break;
	}
} 
	



}
}

