package Average.Student.search;

import java.util.ArrayList;
import java.util.Scanner;

public class Tree {

	public static void main(String[] args) {

		ArrayList<String> abcd = arrayName();
			 
		 String name = inputName();
			 
	      arraySearch(abcd, name);

	}

	private static void arraySearch(ArrayList<String> abcd, String name) {
		for (int i = 0; i < abcd.size();) {
			if(abcd.contains(name) ){
			System.out.println(name);
			break;
		}else{
			System.out.println("This name : ("+name+") not in DB");
			break;
		}
			}
	}

	private static String inputName() {
		System.out.print("Please enter a name: ");
		  Scanner input = new Scanner(System.in);
		 String name = input.nextLine();
		input.close();
		return name;
	}

	private static ArrayList<String> arrayName() {
		ArrayList<String> abcd = new ArrayList<String>();

		  abcd.add("muhammed");
		  abcd.add("essa");
		  abcd.add("hameed");
		  abcd.add("yousuf");
		  abcd.add("omer");
		return abcd;
	}

}
