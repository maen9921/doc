package Average.Student;

public class Essa {
	int age;
	String name;
	static String company ="Iraq" ;
	

	
	public Essa(int age, String name) {
		
		this.age = age;
		this.name = name;
	}



	public void show(){
		System.out.println(name+" "+age+" "+company);
	}
}
