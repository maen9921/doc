package Average.Student.Loops;

public class InfiniteLoop {

	public static void main(String[] args) {
	
	for ( ; ; ) {
	    
	    // your code 
	}
}}
