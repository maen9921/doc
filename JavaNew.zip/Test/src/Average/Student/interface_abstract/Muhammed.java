package Average.Student.interface_abstract;

public interface Muhammed {

	public void next();
	public void show();
	public void play();
	public void mute();
	public void back();
}
