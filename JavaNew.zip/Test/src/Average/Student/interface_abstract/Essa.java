package Average.Student.interface_abstract;

public abstract class Essa implements Muhammed{

	@Override
	public void next() {
		
		System.out.println("abstract class");

		
	}
	

}


	

