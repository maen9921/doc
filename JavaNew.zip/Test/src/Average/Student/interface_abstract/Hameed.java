package Average.Student.interface_abstract;

public class Hameed extends Essa{

	@Override
	public void show() {
		System.out.println("abstract show");		
	}

	@Override
	public void play() {
		System.out.println("abstract play");
		
	}

	@Override
	public void mute() {
		System.out.println("abstract mute");
		
	}

	@Override
	public void back() {
		System.out.println("abstract back");
		
	}

	
}
