package Average.Student.Drectories;

import java.io.File;

public class Main {

	public static void main(String[] args) {
	
		String newDir = "/home/muhammed/Desktop/Essa/Muhammed/Hameed";
		File f = new File(newDir);
		f.mkdirs();
		System.out.println("Done. !");

	}

}
