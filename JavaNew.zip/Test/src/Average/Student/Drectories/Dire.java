package Average.Student.Drectories;

import java.io.File;

public class Dire {
	public static void main(String[] args) {
			
	File f = null;
	String [] p;
	
	f =  new File("/home/muhammed/Desktop/Essa/");
	
	p = f.list();
	
	for (String s : p) {
		System.out.println(s);
	}

}
}