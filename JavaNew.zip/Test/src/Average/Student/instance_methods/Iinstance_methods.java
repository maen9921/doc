package Average.Student.instance_methods;

public class Iinstance_methods {

	public static void main(String[] args) {
		
				
       Muhammed.essa();

	}
}

class Muhammed{
		      public static void essa(){
	    	  System.out.println("Muhammed Essa");
	      }
}

