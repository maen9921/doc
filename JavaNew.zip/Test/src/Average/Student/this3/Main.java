package Average.Student.this3;



public class Main {

	public static void main(String[] args) {
		
		This name = new This(30,"Muhammed","RAN");

		name.show2();

	}

}
