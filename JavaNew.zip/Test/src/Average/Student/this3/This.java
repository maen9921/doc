package Average.Student.this3;

public class This {
	int num;
	String name;
	String dept;

	public This(int num, String name) {
  		this.num = num;
		this.name = name;
		
	}
		
	public This(int num, String name, String dept) {
		this(num,name);
		this.dept = dept;
	}



	public void show2(){
		System.out.println("name : "+name + " Age:" + num +"  department: "+dept);
	}
	
}
