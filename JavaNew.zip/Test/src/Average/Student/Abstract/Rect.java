package Average.Student.Abstract;

public class Rect extends Shape {
    public int length;
    public int width;
    public Rect (){
     super("rect");
    }

    public Rect(String n, int length, int width) {
        super(n);
        this.length = length;
        this.width = width;
    }

    public void print (){
        System.out.println("this is Rect");
    }

    @Override
    public void area() {
        System.out.println("Area of "+name+"="+(length*width));
    }


}
