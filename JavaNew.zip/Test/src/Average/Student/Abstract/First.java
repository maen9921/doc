package Average.Student.Abstract;

public class First {

    public void print (Shape sh){
        if (sh instanceof Rect){
            System.out.println("this is react ");
        }else if (sh instanceof Square){
            System.out.println("this is square");
        }else
            System.out.println("out of shape ");
    }
}
