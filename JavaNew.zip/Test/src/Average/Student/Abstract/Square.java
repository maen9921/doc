package Average.Student.Abstract;

public class Square extends Shape {

    public int rib;
    public Square() {
        super("Square");
    }

    public Square(String n, int rib) {
        super(n);
        this.rib = rib;
    }

    @Override
    public void print() {
        System.out.println("square");
    }

    @Override
    public void area() {
        System.out.println("Area of "+name+"="+(rib*4));
    }
}
