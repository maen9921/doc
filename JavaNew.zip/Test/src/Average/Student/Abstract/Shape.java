package Average.Student.Abstract;

public abstract class Shape {

    public String name;

    public Shape(String n) {

        this.name = n;
    }

    public abstract void print();
    public abstract void area ();
}