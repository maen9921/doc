package Average.Student.arrayIO;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Main {

	public static void main(String[] args) {
		
try {
	FileOutputStream fos1= new  FileOutputStream("text1.txt");
	FileOutputStream fos2= new  FileOutputStream("text2.txt");
	
	ByteArrayOutputStream byteA = new ByteArrayOutputStream();
	
	byteA.write(100);
	byteA.writeTo(fos1);
	byteA.writeTo(fos2);
	byteA.flush();
	byteA.close();
	System.out.println("Done. !");
} catch (FileNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
} catch (IOException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
	}

}
