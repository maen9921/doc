package Average.Student.wrapper;

public class Main {

	public static void main(String[] args) {
		
int num = 300;

Integer num2 = Integer.valueOf(num);

Integer num3 = num;

System.out.println(num +" "+ num2 +" "+ num3+" ");


	}

}
