package Average.Student.wrapper;

public class Muhammed {

	public static void main(String[] args) {
		

		Integer number = new Integer(10);

		int num = number.intValue();
		int num2 = num;
		
		System.out.println(number +" "+ num +" "+ num2+" ");
	}

}
