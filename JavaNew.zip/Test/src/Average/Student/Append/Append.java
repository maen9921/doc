package Average.Student.Append;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Append {

	public static void main(String[] args) {
	
	    String s = "My name is : Usama Essa Hameed";
			try {
PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter("myFile.txt",true)));
				
				pw.println(s);
				pw.flush();
				pw.close();
				System.out.println("Done. !");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
	}

}
