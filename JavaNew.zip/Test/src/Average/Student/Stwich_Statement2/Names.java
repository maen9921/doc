package Average.Student.Stwich_Statement2;

public enum Names {
	
	MUHAMMED , ESSA , HAMEED ;

}
