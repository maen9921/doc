package Average.Student.this4;

public class Main {

	public static void main(String[] args) {
		
This name = new This();

name.omer();

	}

}
