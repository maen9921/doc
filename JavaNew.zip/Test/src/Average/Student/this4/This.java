package Average.Student.this4;

public class This {

	public void ali(){
		System.out.println("Muhammed Essa Hameed");
	}
	
	public void hayder(){
		this.ali();
		
	}
	
	public void omer(){
		ali();
	}
}
