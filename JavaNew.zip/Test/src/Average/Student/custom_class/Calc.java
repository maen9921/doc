package Average.Student.custom_class;

public class Calc {


	public static void main(String[] args) {

		
			int num = MathOper.operatorSelect();
			SelectOper.operators(num);
					
		}

}
	


