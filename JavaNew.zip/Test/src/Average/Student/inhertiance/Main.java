package Average.Student.inhertiance;

class Employee{
	int salary = 5000;
}

class addValue extends Employee{
	int add = 1000;
}


public class Main {

	public static void main(String[] args) {
		
		addValue av = new addValue();
		
		System.out.println("salary is :" + av.salary);
		System.out.println("increment :" + av.add);
		

	}

}
