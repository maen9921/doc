package Average.Student.constructorMethods;

public class Essa {

	String name ;
	String last_name ;
	int salary ;
	
	public Essa(String s1,String s2){
		name = s1;
		last_name = s2;
	}

	public Essa(String s3, String s4, int n) {
	    name = s3;
	    last_name = s4;
		salary = n;
	}
	
	public void show(){
		System.out.println("name: "+name+"  Last Name: "+last_name+"Salay :"+salary);
	}
	public void show2(){
		System.out.println("name: "+name+"  Last Name: "+last_name);
	}
	
}
