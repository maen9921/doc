package Average.Student.constructorMethods;

public class Muhammed {

int num ;
String name;

public Muhammed(int n,String s){
	num = n;
	name = s;
	
}

public void show(){
	System.out.println("employee name : "+name+"   Age is: "+num);
	
}

	
	
}
