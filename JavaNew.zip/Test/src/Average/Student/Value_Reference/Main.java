package Average.Student.Value_Reference;

public class Main {

	public static void main(String[] args) {
		
//		Essa essa = new Essa();
//		
//		System.out.println("Orginal value :"+essa.name);
//		
//		essa.addName("Hameed");
//		
//		System.out.println("changed value :"+essa.name);

		
		Amar a = new Amar();
		System.out.println("Orginal value :"+a.d);
//		
		a.addValue(a);
		
		System.out.println("changed value :"+a.d);	
		
	}

}
