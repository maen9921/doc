package Average.Student.Value_Reference;

public class Amar {

	double d = 40.0;
	
	public void addValue(Amar a){
		a.d = a.d + 10.0;
	}
}
