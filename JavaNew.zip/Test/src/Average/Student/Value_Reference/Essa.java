package Average.Student.Value_Reference;

public class Essa {

	String name = "Muhammed";
	
	public void addName(String s){
		s = name +"Essa";
		
		
	}
}
