package Average.Student.this2;

public class This {

	int num;
	String name;
	
	This(){
		System.out.println("Muhammed Essa ");
		}

	public This(int num, String name) {
this();
		this.num = num;
		this.name = name;
		
	}
	public void show(){
		System.out.println("name : "+name + " Age:" + num);
	}
	
}
