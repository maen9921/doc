package Average.Student.this2;

public class Main {

	public static void main(String[] args) {
		
This name = new This(30,"Muhammed");

name.show();

	}

}
