package Average.Student.createObject.sub;

public class Muhammed {

public void muh(){
	System.out.println("Muhammed");
}

}
