package Average.Student.overloadMethods;

public class OverloadMethods {

	public static void main(String[] args) {
	
		int num1 = 2;
		int num2 = 8;
		int num3 = 3;
		int result = sum(num1,num2);
        System.out.println("the result is : "+result);
        int result2 = sum(num1,num2,num3);
        System.out.println("the result is : "+result2);
        
        String str1 = "12";
        String str2 = "9";
        int result3 = sum(str1,str2);
        System.out.println("the result is : "+result3);
	}
	
	private static int sum(int n,int m){
		return n+m;
	}
	private static int sum(int n,int m,int v){
		return n+m+v;
	}
	private static int sum(String s1 , String s2){
		int v1 = Integer.parseInt(s1);
		int v2 = Integer.parseInt(s2);
		return v1+v2;
	}
}
