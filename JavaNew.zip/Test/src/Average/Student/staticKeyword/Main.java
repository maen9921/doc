package Average.Student.staticKeyword;

public class Main {

	public static void main(String[] args) {

//Muhammed name = new Muhammed(30,"Muhammed");
//Muhammed name2 = new Muhammed(27,"Essa");
//Muhammed name3 = new Muhammed(24,"Hameed");
//
//name.show();
//name2.show();
//name3.show();
System.out.println("-------------------------------------");


//java.lang.Math math1 = new java.lang.Math();
//java.lang.Math math2 = new java.lang.Math();
//java.lang.Math math3 = new java.lang.Math();
System.out.println("-------------------------------------");
System.out.println("-------------------------------------");

Essa.changeCompany();

Essa ess1 = new Essa(30,"Muhammed");
Essa ess2 = new Essa(30,"Ahmed");
Essa ess3 = new Essa(30,"Hussien");

ess1.show3();
ess2.show3();
ess3.show3();
	}

}
