package Average.Student.staticKeyword;

public class Math {

	int count=0;
	
public Math(){
	count++;
	System.out.println(count);
}


	
	
}
