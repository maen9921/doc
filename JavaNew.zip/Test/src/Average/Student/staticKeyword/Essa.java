package Average.Student.staticKeyword;

public class Essa {
	int age;
	String name;
	static String company ="Iraq" ;
	
	static void changeCompany(){
		company ="Kirkuk" ;
	}
	
	public Essa(int n ,String s){
		name = s;
		age = n;
	}
	
	public void show3(){
		System.out.println(name+" "+age+" "+company);
	}
}
