package Average.Student.staticKeyword;

public class Muhammed {

	int age;
	String name;
	static String company ="Iraq" ;
	
	public Muhammed(int n ,String s){
		name = s;
		age = n;
	}
	
	public void show(){
		System.out.println(name+" "+age+" "+company);
	}
}
