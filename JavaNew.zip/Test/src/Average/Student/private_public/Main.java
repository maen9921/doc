package Average.Student.private_public;

public class Main {

/*	public static void main(String[] args) {
	
		Muhammed mu = new Muhammed();
		mu.myName();
		mu.myage();
	Essa ess = new Essa();
	System.out.println(ess.myname("Muhammed"));
	System.out.println(ess.mylast_name("Essa"));
	}
*/
}
