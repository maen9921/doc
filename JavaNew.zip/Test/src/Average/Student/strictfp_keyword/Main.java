package Average.Student.strictfp_keyword;

public class Main {

	public static void main(String[] args) {
		
//Strictfp : Methods - Class - Interface تستخدم
//
//		strictfp class muhammed{}
//		strictfp interface muhammed{}
//		strictfp void muhammed{}
//		
//Strictfp not applied on لاتستخدم:
//	Abstract methods - variables - constructor 

	}

}
