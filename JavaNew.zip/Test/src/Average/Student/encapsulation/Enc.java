package Average.Student.encapsulation;

public class Enc {

	public static void main(String[] args) {
		


	}

}
