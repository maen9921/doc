package Average.Student.cloneobject;

public class Ahmed implements Cloneable{

	int id;
	String name;
	String last_name;
	public Ahmed(int id, String name, String last_name) {
		super();
		this.id = id;
		this.name = name;
		this.last_name = last_name;
	}
	
	public Object clone()throws CloneNotSupportedException{
		return super.clone();
	}
	
	
}
