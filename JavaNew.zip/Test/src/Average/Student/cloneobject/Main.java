package Average.Student.cloneobject;

public class Main {

	public static void main(String[] args) {
		
try {
	Ahmed a = new Ahmed(1000,"Ahmed","Essa");
	Ahmed a1 = (Ahmed)a.clone();
	System.out.println("first name is :"+a.name);
	System.out.println("first name is :"+a1.name);
	
} catch (CloneNotSupportedException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}






	}

}
