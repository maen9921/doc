package Average.Student.StringClass;

public class String_class2 {

	public static void main(String[] args) {
		
		String s1 = "Muhammed Essa";
		StringBuilder mn = new StringBuilder(s1);
		
		mn.append(" Hameed");
	

		System.out.println(mn);

	}

}
