package Average.Student.Coverting_Numeric;

public class DataType {
    public static void main(String[] args) {

        double d=3.22;
        int value= (int)d; //هنا سوف تختفي القيمة القديمة وتخزن القيمة الجديدة
        System.out.println(value);//result=3  loss data=0.22

        double a=3.22; //Helper Class هنا لقد قمنا بالحفاظ على القيمة  بمتغير اخر
        double a1=a;//نستطيع الوصول اليها متى ما اردنا
        int a2=(int)a1;
        System.out.println(a2);
        System.out.println(a);
        int number=128;
        byte convertNum=(byte)number;
        System.out.println(convertNum);
        //تم تغيير الرقم الى سالب =- 128
        //بسبب أن البايت من -128 الى 127
        // data type :
        //1-primitive type :1-short 2-byte 3-int 4-long 5-float 6-double 7-boolean 8-char

        // 2- reference type: 1-String 2-args

        // conditional operators : && and  , || or   , ?: ternary >> ? if >> : else

        //type comparision operators : instance of يحتوي

        /* math operator:
        int value=5
        value+=5;
        value-=5;
        value*=5;
        value/=5;
        value%=5;
         incrementing and decrementing
         int value=10;
         value++ // 11
         value-- //9
         value+=5  //15
         value-=5  //15
         value *=5 //50
         value /=5  //2
         value%=5   //0

         Postfix and Prefix incrementing

         int value=10;
         postfix
         System.out.println(value++) 10,11
         prefix
         System.out.println(++value);11,11

*/

        String s1="Hello";
        String s2="Hello"; //هنا يعامل ال string  ك primitive data
        String s3=new String("Hello"); //هنا ال string يعامل ك object
        if (s1 == s3) //operators equality Strings
            System.out.println("They Match");
        else
            System.out.println("No Match !");



    }
}
