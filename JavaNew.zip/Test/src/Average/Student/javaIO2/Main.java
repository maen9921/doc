package Average.Student.javaIO2;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Main {

	public static void main(String[] args) {
		
BufferedReader br = null;
PrintWriter pw = null;

try {
	br = new BufferedReader(new FileReader("myFile.txt"));
	pw = new PrintWriter(new FileWriter("newFile.txt"));
	
	String s;
	
	while ((s = br.readLine()) != null) {
	
		pw.println(s);
		
	}
	br.close();
	pw.close();
	System.out.println("Copied !");
} catch (FileNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
} catch (IOException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}

	}

}
