package Average.Student.Plauginx;

public class Obj {

    public void className (Object o){
        if (o instanceof A)
            System.out.println("this is class A");
        else if (o instanceof Pdf)
            System.out.println("this is class Pdf ");
        else
            System.out.println("Anthor class");
    }
}
