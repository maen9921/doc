package Average.Student.Plauginx;

public interface Xplugin {
    public void start();
    public void execute ();
    public void shutDawn ();
}
