package Average.Student.Plauginx;

public class Pdf implements Xplugin {
    @Override
    public void start() {
        System.out.println("Pdf Start.....");
    }

    @Override
    public void execute() {
        System.out.println("Pdf Executed ...");
    }

    @Override
    public void shutDawn() {
    this.close();
    }
    public void close (){
        System.out.println("Pdf closed");
    }
}
