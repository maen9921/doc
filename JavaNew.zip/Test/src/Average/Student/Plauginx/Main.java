package Average.Student.Plauginx;

import Average.Student.Abstract.First;
import Average.Student.Abstract.Rect;
import Average.Student.Abstract.Square;
import Average.Student.MyInterFace.InterFace1;

public class Main {

    public static void main(String[] args) {

        Rect r=new Rect();
        Square s=new Square();
        Rect r1=new Rect("rectangle",10,20);

        First f=new First();


//        f.print(r1);
//        f.print(s);





    }
}
