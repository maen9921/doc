package Average.Student.Plauginx;

public class A {

    public void startPlugin (Xplugin xp){

        xp.start();
    }
    public void executedPlugin (Xplugin xp){
        xp.execute();
    }
    public void closedPlugin (Xplugin xp){
        xp.shutDawn();
    }
}
