package Average.Student.Plauginx;

public class StartPro {
    public static void main(String[] args) {

        Pdf pdf=new Pdf();
        A a=new A();

        a.startPlugin(pdf);
        a.executedPlugin(pdf);
        a.closedPlugin(pdf);
    }
}
