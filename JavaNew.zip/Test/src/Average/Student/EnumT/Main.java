package Average.Student.EnumT;

import Average.Student.Plauginx.A;
import Average.Student.Plauginx.Obj;
import Average.Student.Plauginx.Pdf;

public class Main {

    public static void main(String[] args) {

//        System.out.println("the Gender is "+Gender.MALE+" And "+Gender.FEMALE);

//        System.out.println("ID "+Gender.MALE.id+" Gender "+Gender.MALE.name);
//        System.out.println(A.GenderX.MALE.id);
//        System.out.println("ID "+Gender.FEMALE.id+" Gender "+Gender.FEMALE.name);
//        System.out.println(A.GenderX.MALE.name);
//        System.out.println(A.GenderX.FEMALE.id);
//        System.out.println(A.GenderX.FEMALE.name);
//        Gender.MALE.printString();
//        Gender.FEMALE.printString();

//        Gender x= Gender.MALE;

//        switch (x){
//            case FEMALE:
//                System.out.println("female");
//                break;
//            case MALE:
//                System.out.println("Male");
//                break;
//            default:
//                System.out.println("Wrong");

//
//        try {
//
//
//        Gender x=Gender.valueOf("FEMALE");
//        x.printString();}
//        catch (IllegalArgumentException e){
//            System.out.println("there is no constant ");
//        }

//        A a1=new A();
//        System.out.println(a1.getClass().getTypeName());
        A a=new A();
        Pdf a1=new Pdf();
        Obj o=new Obj();

        o.className(o);
        }

    }

