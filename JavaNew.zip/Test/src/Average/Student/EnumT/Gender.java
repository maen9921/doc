package Average.Student.EnumT;

public enum Gender {
    MALE (15,"this male") {
        @Override
        public void printString(){
            System.out.println("male");
        }
    },FEMALE(10,"this female"){
        @Override
        public void printString(){
            System.out.println("female");
        }
    };
    public int id;
    public String name;
    Gender(int i, String s) {

        this.id=i;
        this.name=s;
    }

    public abstract void printString();
}
