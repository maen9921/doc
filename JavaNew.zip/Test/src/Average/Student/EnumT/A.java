package Average.Student.EnumT;

import javax.smartcardio.ATR;

public class A {
    public int number;

    public enum  GenderX{
        MALE (10,"male"),FEMALE (15,"female");
        public int id;
        public String name;
        GenderX(int i, String z) {
            this.id=i;
            this.name=z;
        }
    }
}
