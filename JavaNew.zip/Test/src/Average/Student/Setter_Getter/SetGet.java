package Average.Student.Setter_Getter;

public class SetGet {
    public static void main(String[] args){

        Employee emp = new Employee(3201,"Muhammed ","NPO ","Erbil");

        emp.show();


        String name = emp.getName();
        System.out.println(name);
        emp.setName("Omer ");
        emp.show();
        emp.setName("Akeel ","PAbis ");
        emp.show();
    }
}
