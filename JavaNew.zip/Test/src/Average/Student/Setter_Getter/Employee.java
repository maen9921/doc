package Average.Student.Setter_Getter;

public class Employee {
    private int id;
    private String name;
    private String dept;
    private String adds;

    public Employee(int num ,String nam,String depts,String addds){

        id = num;
        name = nam;
        dept = depts;
        adds = addds;


    }

    public String getName(){
        return name;
    }

    public void setName(String s){
        name = s;
    }
    public void setName(String s,String d){
        name = s;
        dept = d;
    }



    public void show(){
        System.out.println("Id :"+id+" Name :"+ name +"dept :"+ dept
                             +"adds :"+ adds);
    }

}
