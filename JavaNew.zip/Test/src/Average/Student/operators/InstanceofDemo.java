package Average.Student.operators;

public class InstanceofDemo { public static void main(String[] args) {

    String M = "Muhammed";

    if (M instanceof java.lang.String){

        System.out.println("M is a String");
    }


}
}
